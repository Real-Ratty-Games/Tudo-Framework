$input v_texcoord0

#include <common.sh>

uniform vec4 color;

void main()
{
	gl_FragColor = color;
}
